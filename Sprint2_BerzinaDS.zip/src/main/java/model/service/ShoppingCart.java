package model.service;

import model.Food;
import model.constants.Discount;

public class ShoppingCart {

    Food[] purchases = new Food[3]; //вопрос: судя по заданию, конструктор должен содержать только 1 параметр - массив элементов Food и поле из массивов элементов Food. Как мне улучшить код и задать массив элементов в классе, если я не знаю ни его длину, ни сами элементы. Как только я убираю new Food[3] сразу получаю ошибку в конструкторе, когда пытаюсь перебрать элементы (this.purchases[i] =purchases[i];) и Exception in thread "main" java.lang.NullPointerException на выходе

    public ShoppingCart(Food purchases[]) { // конструктор
        for(int i = 0; i < purchases.length; i++) {
            this.purchases[i] =purchases[i];
        }
    }

    public double getSum(){ //общая сумма товаров в корзине без скидки
        double sum = 0;
        for (int i = 0; i < purchases.length; i++) {
            sum += purchases[i].finalPrice();
        }
        return sum;
    }

   public double getSumWithDiscount(){ //общая сумма товаров в корзине со скидкой,
        double sum = 0;
        for (int i = 0; i < purchases.length; i++) {
            sum += purchases[i].discountPrice();
        }
        return sum;
    }

    public double getSumOfVegan() { //общая сумма всех вегетарианских продуктов в корзине без скидки.
        double sum = 0;
        for (int i = 0; i < purchases.length; i++) {
            if (purchases[i].isVegetarian()) {
                sum += purchases[i].finalPrice();
            }
        }
            return sum;

    }
}
