package model.constants;

public class Colour {
    public static final String DISCOUNT_COLOUR = "red"; //цвет яблок для скидки
}
