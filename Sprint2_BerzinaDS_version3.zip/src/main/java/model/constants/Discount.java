package model.constants;

public class Discount {
    public static final int DISCOUNT_FOR_ALL = 0; //размер скидки для всех
    public static final int DISCOUNT_FOR_APPLE = 60; //размер скидки для яблок заданного цвета
}
