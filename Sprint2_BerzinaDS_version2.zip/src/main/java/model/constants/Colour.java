package model.constants;

public class Colour {
    public static final String discountColour = "red"; //цвет яблок для скидки
}
