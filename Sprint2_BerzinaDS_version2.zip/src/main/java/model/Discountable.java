package model;

public interface Discountable {
    double getDiscount();
}
